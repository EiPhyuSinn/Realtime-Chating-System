<?php

use App\Events\Message;
use App\Http\Controllers\PusherController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Pusher\Pusher;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Route::get('/', function () {
//     return view('index');
// });

Route::get('/',[PusherController::class,'chat']); 

Route::post('/sendMessage',function(Request $request){
  $username = $request->input('username');
  $message = $request->input('message');
  //trigger broadcasting 
   
  broadcast(new Message($username, $message))->toOthers();
  return response()->json(['message' => 'Message sent successfully']);
})->name('sendMessage');

Route::post('/sendImage',function(Request $request){
  $username = $request->input('username');
  $message = $request->file('message');
  // $path = $message->store('images');
  $message->move(public_path().'/images/',$message->getClientOriginalName());
  broadcast(new Message($username, $message->getClientOriginalName()))->toOthers();
  return response()->json(['message' => 'image sent successfully']);
})->name('sendImage');


Route::get('/lightBox',function(){
  return view('lightbox');
});
 


