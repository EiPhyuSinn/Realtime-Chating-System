<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>ChatVibe</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>

    <!-- Pusher JS -->
    <script src="https://js.pusher.com/7.0/pusher.min.js"></script>

    <style>
        .btn-fixed-length {
            width: 350px;
            box-shadow: 0 0 20px rgba(15, 15, 15, 0.1);
            background-color: #fff;
            border-radius: 15px;
        }
    </style>
</head>
<body>
    <div class="container mb-3">
        <!-- Navigation Bar -->
        <nav class="navbar navbar-expand-lg bg-body-tertiary my-3">
            <div class="container-fluid p-3">
                <a class="navbar-brand" href="#">ChatVibe</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link disabled" aria-disabled="true">A chatting platform where you can chat with anyone online.</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <!-- Username Form -->
        <div class="mb-3" id="nameDiv">
            <form action="" id="nameForm" class="input-group">
                <input type="text" class="form-control" id="username" placeholder="Set a name to use in the chat..">
                <input type="submit" class="btn btn-primary" value="Set">
            </form>
        </div>

        <!-- Chat Messages -->
        <div class="mt-5">
            <p id="name">ChatBox</p>
            <div id="messages"></div>
        </div>

        <!-- Message Send Form -->
        <div class="my-3 fixed-bottom container" style="display:none" id="messageDiv">
            <div class="mb-3 col-md-2">
                <form action="" id="sendMessage" class="input-group">
                    <input type="text" class="form-control" id="message" placeholder="Send message...">
                    <input type="submit" class="btn btn-primary" value="Send">
                </form>
            </div>
        </div>
    </div>

    <script>
          Pusher.logToConsole = true;
           
        $(document).ready(function(){
            // Pusher Initialization
            var pusher = new Pusher('050b52b875367e556d60', {
    cluster: 'eu',
    encrypted: true
});


         

            var channel = pusher.subscribe('chat');
            console.log('pusher',pusher)
            console.log('channel',channel)
            // Username Form Submission
            $('#nameForm').submit(function(event){
                event.preventDefault();
                submitUsername();
            });

            function submitUsername(){
                var username = $('#username').val();
                if(username === ''){
                    alert('Enter username');
                    return;
                }

                $('#nameDiv').css('display','none');
                $('#messageDiv').css('display','flex');
                $('#name').html('<b>' + username + '</b> chatbox');
            }

            // Message Send Form Submission
            $('#sendMessage').submit(function(event){
                event.preventDefault();
                sendMessage();
            });

            function sendMessage(){
                var username = $('#username').val();
                var message = $('#message').val();

                if (message === '') {
                    alert('Enter a message');
                    return;
                }

                $('#message').val('');

                // $('#messages').append('<button type="button" class="btn btn-fixed-length text-start mb-2" disabled><b>' + username + '</b>: ' + message + '</button><br>');

                // Send message to Laravel server using Ajax
                $.ajax({
                    url: '{{ route('sendMessage') }}',
                    method: 'POST',
                    data: {
                        username: username,
                        message: message,
                        _token: '{{ csrf_token() }}'
                    },
                    success: function(response){
                        console.log(response.message);
                    },
                    error: function(error){
                        console.log(error);
                    }
                });
            }
           
            // Pusher Event Handling
            channel.bind('App\\Events\\Message', function(data) {
    console.log('i am success');
    $('#messages').append('<button type="button" class="btn btn-fixed-length text-start mb-2" disabled><b>' + data.username + '</b>: ' + data.message + '</button><br>');
});

        
        });
    </script>
   
</body>
</html>

