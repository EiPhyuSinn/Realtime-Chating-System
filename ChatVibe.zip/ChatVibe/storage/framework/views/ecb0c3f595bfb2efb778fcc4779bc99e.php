<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>ChatVibe</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"/>

    <!-- Pusher JS -->
    <script src="https://js.pusher.com/7.0/pusher.min.js"></script>
    
    <style>
        .btn-fixed-length {
            width: 350px;
            box-shadow: 0 0 20px rgba(15, 15, 15, 0.1);
            background-color: #fff;
            border-radius: 15px;

        }
        .left{
            display: flex;
            align-items: center;
        }
        .right{
            display: flex;
            align-items: center;
            justify-content: flex-end; /* Align items to the right */
        
        }
        .message {
            
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5); /* Black box shadow */
            padding: 10px; /* Optional padding for spacing */
            background-color:rgb(124, 121, 121);
            border-top-left-radius: 15px; /* Border radius for top-left corner */
            border-bottom-left-radius: 15px; /* Border radius for bottom-left corner */
            border-top-right-radius: 15px; /* Border radius for top-right corner */
            border-bottom-right-radius: 15px; 
            max-width:500px;
            padding: 10px;
            color: white;
            }
        .right .message{
            background-color:rgb(85, 85, 173)
        }

        .left span{
            display: flex; /* Use flexbox for layout within the span */
            align-items: center; /* Center items vertically */
        }

        .right span{
            display: flex; /* Use flexbox for layout within the span */
            align-items: center; /* Center items vertically */
            justify-content: flex-end;
        }
        .image-message{
            height: auto;
            width: 40%;
        }

        .profile{
            width: 50px; /* Set the width of the image */
            height: 50px; /* Set the height of the image */
            border-radius: 50%; /* Optional: Make the image circular */
            margin-right: 10px; /* Optional margin between image and text */
            margin-left : 10px;
        }

       .send-button{
            border-top-left-radius: 15px; /* Border radius for top-left corner */
            border-bottom-left-radius: 15px; /* Border radius for bottom-left corner */
            border-top-right-radius: 15px; /* Border radius for top-right corner */
            border-bottom-right-radius: 15px; 
          
            padding: 10px;
       }
       .submitBtn{
        color:white
       }
       .addIcon {
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        color: white;
        font-weight: bold;
        width: 40px; /* Adjust the width as needed */
        height: 40px; /* Set the height to match the width for a perfect circle */
        background-color: black;
        margin-right: 2px;
        cursor: pointer; /* Add a pointer cursor to indicate it's clickable */
        }
       
    </style>
</head>
<body>
    <div class="container mb-3">
        <!-- Navigation Bar -->
        <nav class="navbar navbar-expand-lg bg-body-tertiary my-3">
            <div class="container-fluid p-3">
                <a class="navbar-brand" href="#">ChatVibe</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link disabled" aria-disabled="true">A chatting platform where you can chat with anyone online.</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <!-- Username Form -->
        <div class="mb-3" id="nameDiv">
            <form action="" id="nameForm" class="input-group">
                <input type="text" class="form-control" id="username" placeholder="Set a name to use in the chat..">
                <input type="submit" class="btn btn-primary" value="Set">
            </form>
        </div>
       

        <!-- Chat Messages -->
        <div class="mt-5">
            <p id="name">ChatBox</p>
            <div id="messages" class="container">
              
        </div>
   

        <!-- Message Send Form -->
<div class="mt-5 container send-button fixed-bottom " style="" id="messageDiv" >
    <form action="" id="sendMessage" class="input-group">
        <input type="text" class="form-control" id="message" class="toggle-input" placeholder="Send message...">
        <input type="file" class="form-control" id="fileMessage" style="display: none;" value=null>
        <!-- Plus Icon (Clickable) -->
        <label for="fileMessage" class="fas fa-plus plus-icon addIcon" id="plusIcon" style="cursor: pointer;"></label>
        <button type='submit' class="btn btn-primary"><i class='fas fa-paper-plane'></i></button>
    </form>
</div>
    </div>
    <!-- Add this modal structure at the end of your body section -->
<div class="modal" id="imageModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Image Preview</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <img id="modalImage" class="img-fluid" alt="Image Preview" style="max-width:100%;">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <!-- Add your "Save" button here if needed -->
            </div>
        </div>
    </div>
</div>

</body>

<script src="https://cdn.jsdelivr.net/npm/bs5-lightbox@1.8.3/dist/index.bundle.min.js"></script>

<!-- Add your HTML structure above this line -->

<script>
    $(document).ready(function () {    
    
        Pusher.logToConsole = true;
        var pusher = new Pusher('050b52b875367e556d60', {
            cluster: 'eu',
            encrypted: true
        });
    
        var channel = pusher.subscribe('chat');
    
        function scrollToBottom() {
            var messagesContainer = $('#messages');
            messagesContainer.scrollTop(messagesContainer[0].scrollHeight);
        }
    
        $('#nameForm').submit(function (event) {
            event.preventDefault();
            submitUsername();
        });
    
        function submitUsername() {
            var username = $('#username').val();
            if (username === '') {
                alert('Enter username');
                return;
            }
    
            $('#nameDiv').css('display', 'none');
            $('#messageDiv').css('display', 'flex');
            $('#name').html('<b>' + username + '</b> chatbox');
        }
    
        $('#fileMessage').on('change', function () {
            var selectedFile = this.files[0];
            $('#message').attr('placeholder', selectedFile.name);
            $('#message').prop('disabled', true);
        })
    
        $('#sendMessage').submit(function (event) {
            event.preventDefault();
            sendMessage();
        });
    
        function sendMessage() {
            var username = $('#username').val();
            var message = $('#message').val();
            var fileMessage = $('#fileMessage')[0].files[0];
    
            if (message === '' && !fileMessage) {
                alert('Enter a message or select a file');
                return;
            }
    
            if (message !== '' && !fileMessage) {
                $('#messages').append(`
                    <div class="right mb-1">
                        <span> 
                            <p class="message">${message}</p>
                            <img class="profile" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQoyPprnKsxGb2AVK2LPjwZ919_iwKYutzJKsQfTroZew&s" alt="">
                        </span>
                    </div>
                `);
    
                $.ajax({
                    url: '<?php echo e(route('sendMessage')); ?>',
                    method: 'POST',
                    data: {
                        username: username,
                        message: message,
                        _token: '<?php echo e(csrf_token()); ?>'
                    },
                    success: function (response) {
                        console.log(response.message);
                        scrollToBottom();
                    },
                    error: function (error) {
                        console.log(error);
                    }
                });
            }
    
            if (fileMessage) {
                if (fileMessage.type.startsWith('image/')) {
                    var reader = new FileReader();
                    reader.onload = function (e) {
                        $('#messages').append(`
                            <div class="right mb-2 mt-2">
                                <span> 
                                    <img class="image-message" src="${e.target.result}" data-toggle="lightbox"  alt="">
                                    <img class="profile" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQoyPprnKsxGb2AVK2LPjwZ919_iwKYutzJKsQfTroZew&s" alt="">
                                </span>
                            </div>
                        `);
                    };
                    scrollToBottom();
                    reader.readAsDataURL(fileMessage);
    
                    var formData = new FormData();
                    formData.append('username', username);
                    formData.append('_token', '<?php echo e(csrf_token()); ?>');
                    formData.append('message', fileMessage);
    
                    console.log('username', formData.get('message'));
                    $.ajax({
                        url: '<?php echo e(route('sendImage')); ?>',
                        method: 'POST',
                        data: formData,
                        processData: false,
                        contentType: false,
                        success: function (response) {
                            console.log(response.message);
                            scrollToBottom();
                        },
                        error: function (error) {
                            console.log(error);
                        }
                    });
                } else {
                    console.log('Selected file is not an image.');
                }
            }
    
            $('#fileMessage').val("");
            $('#message').attr('placeholder', 'Send Message...');
            $('#message').prop('disabled', false);
            $('#message').val("");
    
            channel.bind('App\\Events\\Message', function (data) {
                console.log('in the loop');
                if (data.username.trim() !== $('#username').val().trim()) {
                     
                    var imageUrl = data.message;
                    console.log('imageurl:',imageUrl)
                    var fileExtension = imageUrl.split('.').pop().toLowerCase();
                   
                    if ($.inArray(fileExtension, ['png', 'jpg', 'jpeg', 'gif']) !== -1) {
                        console.log('image channel')
                        $('#messages').append(`
                            <div class="left mb-2"> 
                                <span> 
                                    <img class="profile" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQoyPprnKsxGb2AVK2LPjwZ919_iwKYutzJKsQfTroZew&s" alt="">
                                    <img class="image-message" data-toggle="lightbox" src="<?php echo e(asset('images/${imageUrl}')); ?>"  alt="">
                                </span>
                            </div>
                        `);
                        
                    } else {
                        console.log('message channel');
                        $('#messages').append(`
                            <div class="left mb-1">
                                <span> 
                                    <img class="profile" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQoyPprnKsxGb2AVK2LPjwZ919_iwKYutzJKsQfTroZew&s" alt="">
                                    <p class="message">${data.message}</p>
                                </span>
                            </div>
                        `);
                    }
                }
            });
            scrollToBottom();
        }
    
        // Use event delegation for click event on .image-message
        $('#messages').on('click', '.image-message', function () {
            // Get the source attribute of the clicked image
            var imageUrl = $(this).attr('src');
    
            // Open Bootstrap modal
            $('#imageModal').modal('show');
    
            // Set the image source in the modal
            $('#modalImage').attr('src', imageUrl);
        });
        scrollToBottom();
    });
    </script>
    
</html>
</html>

<?php /**PATH /Users/eiphyusinn/Desktop/Laravel/ChatVibe/resources/views/index2.blade.php ENDPATH**/ ?>